// Entry point
export function bootstrapApp(): void {
  console.log("App initialized successfully from inside zip archive!");
}

bootstrapApp();
