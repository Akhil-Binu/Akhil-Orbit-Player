import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="header">
      <h1>Orbit Starter App</h1>
    </header>
  );
};
