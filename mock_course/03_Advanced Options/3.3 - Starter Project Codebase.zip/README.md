# Starter Project 🚀

Welcome to the starter codebase template for Akhil Orbit Player students!

## Quick Start
```bash
npm install
npm run dev
```

Happy coding!